<?php
include_once 'setting.inc.php';
